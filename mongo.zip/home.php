<!DOCTYPE html>
<html>
<head>
<style >
	
	a{
		text-decoration: none;
		color: black;
		padding: 30px;
		font-family: arial;
	}
	a:hover{
		color: red;
	}
	#img2{
		margin-top: 40px;
		border-radius: 50%;
		width: 200px;
		height: 200px;
	}
	.d3{
				float: left;
				margin-left: 80px;
				margin-top: 20px;
				
	}
	        
	        .i1 {
	        	width:230px;
	        	float: left;
				margin-left:30px;	
	        }
	        .i1 p {
	        	text-align: center;
	        	margin-left: 35PX;
	        	color: black;
	        }
	        .i1 p:hover{
		color: purple;
	}
	       
body {
	margin: 0px;
}

.header{
  position: fixed;
  margin : 0 auto;
  width: 100%;
}

</style>


	<title></title>
</head>
<body>
<div class="d3">
   <div class="i1">
	<a href="cs.php" ><img src="images/cs.jpg" id="img2" ></a>
	<a href="cs.php"><p>Computer Science </p></a>
	</div>
	<div class="i1">
	 <a href="civil.php"><img src="images/civil.png" id="img2"></a>
	 <a href="civil.php"><p>Civil</p></a>
	 </div>
	 <div class="i1">
	<a href="mech.php"><img src="images/mech.png" id="img2"></a>
	<a href="mech.php"><p>Mechnical</p></a>
	</div>
	<div class="i1">
	 <a href="ece.php"><img src="images/ece.jpg" id="img2" ></a>
	 <a href="ece.php"><p>Electronics & Communication</p></a>
	 </div>
	 <div class="i1">
	 <a href="mca.php"><img src="images/mca.png" id="img2"></a>
	 <a href="mca.php"><p>Masters of Computer Application</p></a>
	 </div>
</div>
</body>
</html>